﻿using System;
using System.Collections.Generic;

namespace FragrantWorld.Modeles;

public partial class ProductCategory
{
    public int CategoryId { get; set; }

    public string CategoryName { get; set; } = null!;
}
